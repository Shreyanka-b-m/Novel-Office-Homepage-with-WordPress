# wordpress-assignment
Custom WordPress theme for Novel Office assignment
